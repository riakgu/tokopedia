# BigToken - BOT
Fungsi script ini untuk registrasi dan verifikasi otomatis.
Dibuat dengan NodeJS.
# Requirement
- nodejs 8.6.0 +
- internet
- kopi
- cewe
# How to use
```sh
$ git clone https://github.com/wfajriansyahh/bigtoken.git
$ cd bigtoken
$ npm install
$ read -p "Enter your refferal : " reff; sed -i "s/RMAL4SE4L/${reff}/g" index.js
$ node index.js
```
